<script src="https://use.fontawesome.com/6e1f898155.js"></script>
<header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <a href="#" class="logo"><img src="assets/img/dccLogo.svg" style="width:30px;"><b> Code Community  Admin Dashboard</b></a>
            <div class="nav notify-row" id="top_menu">
                </ul>
            </div>
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php">Logout</a></li>
            	</ul>
            </div>
        </header>
<style>
body {
    color: #797979;
	background: #f2f2f2;
    font-family: 'Ruda', sans-serif;
    padding: 0px !important;
    margin: 0px !important;
    font-size:13px;
}


select, textarea {
width: 100px;
height:auto;
border: none;
border-radius: 4px;
background-color:inherit;
color:black;
margin-top: 0px;
margin-bottom: 0px;
resize: vertical;
}
#note {
	width:200px;
	box-sizing:border-box;
	direction:ltr;
	display:block;
	line-height:0.5;
	padding:0px 0px 80px;
	border-radius:3px;
	border:1px solid #F7E98D;
	font:13px Tahoma, cursive;
	transition:box-shadow 0.5s ease;
	box-shadow:0 4px 6px rgba(0,0,0,0.1);
	font-smoothing:subpixel-antialiased;
	background:linear-gradient(#F9EFAF, #F7E98D);
	background:-o-linear-gradient(#F9EFAF, #F7E98D);
	background:-ms-linear-gradient(#F9EFAF, #F7E98D);
	background:-moz-linear-gradient(#F9EFAF, #F7E98D);
	background:-webkit-linear-gradient(#F9EFAF, #F7E98D);
}
p.test {
    width: 100px; 
    border: none;
    word-wrap: break-word;
}
textarea#content{
    width:200px;
	box-sizing:border-box;
	direction:ltr;
	display:block;
	line-height:1;
	padding:1px 1px 80px;
    background-color:inherit;
}

</style>