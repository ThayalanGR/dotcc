<ul class="nav navbar-nav" style="float:right;">
    <li>
    <button class="btn btn-link navbar-btn navbar-right" type="button" id="myBtn" style=""><strong>Login / Register</strong></button>
    </li>                    
</ul>






