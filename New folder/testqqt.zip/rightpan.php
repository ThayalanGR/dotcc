
<div class="col-sm-2 sidenav">
              <container>
                  <div class="jumbotron">
                          <h2 style="text-align:center;">ADDs</h2>
                  </div>
              </container>
                <container>
                  <div class="jumbotron">
                          <h2 style="text-align:center;">ADDs</h2>
                  </div>
              </container>
              <container>
                  <div class="jumbotron">
                          <h2 style="text-align:center;">ADDs</h2>
                  </div>
              </container>
              <container>
                  <div class="jumbotron">
                          <h2 style="text-align:center;">ADDs</h2>
                  </div>
              </container>
              <container>
                  <div class="jumbotron">
                          <h2 style="text-align:center;">ADDs</h2>
                  </div>
              </container>
              <container>
                  <div class="jumbotron">
                          <h2 style="text-align:center;">ADDs</h2>
                  </div>
              </container>

              </div>
             </div>
    </div>
</div>